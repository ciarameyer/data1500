# load libraries
require(tidyverse)
require(ggbeeswarm)
require(lubridate)
require(ggstream)

s24 <- read_csv("24.csv")
s2425 <- read_csv("2425.csv")
s2526 <- read_csv("2526.csv")

s24 <- s24 %>%
  select(-c(13, 14, `Attendance Rank`)) %>%
  mutate(`Percent of Venue Cap` = parse_number(`Percent of Venue Cap`)) %>%
  mutate(Date = mdy(Date)) %>%
  mutate(id = row_number()) %>%
  mutate(season = "2024")
s2425 <- s2425 %>%
  select(-`Attendance Rank`) %>%
  mutate(`Percent of Venue Cap` = parse_number(`Percent of Venue Cap`)) %>%
  mutate(Date = mdy(Date)) %>%
  mutate(id = row_number()) %>%
  mutate(season = "2024-25")
s2526 <- s2526 %>%
  select(-`Attendance Rank`) %>%
  mutate(`Percent of Venue Cap` = parse_number(`Percent of Venue Cap`)) %>%
  mutate(Date = mdy(Date)) %>%
  mutate(id = row_number()) %>%
  filter(`Percent of Venue Cap` != 0) %>%
  mutate(season = "2025-26")

full <- bind_rows(s24, s2425, s2526) %>%
  mutate(id = row_number()) %>%
  mutate(country = case_when(
    Venue %in% c(
      "Coca-Cola Coliseum",
      "TD Place",
      "Place Bell",
      "Scotiabank Arena",
      "Bell Centre",
      "Videotron Centre",
      "Rogers Arena",
      "Rogers Place",
      "Scotiabank Centre",
      "Canada Life Centre",
      "Scotiabank Saddledome",
      "Canadian Tire Centre"
    ) ~ "Canada",
    
    TRUE ~ "USA"
  ))

ggplot(full, aes(x = id, y = `Percent of Venue Cap`, color = `Home Team`)) +
  geom_jitter() +
  geom_smooth(method = "lm", se = FALSE)

by_day_analysis <- full %>%
  group_by(`Day of Week`) %>%
  summarize(average_attendance = sum(`Published Attendance`)/n())

by_home_team2 <- full %>%
  group_by(`Home Team`) %>%
  summarize(average_attendance = sum(`Percent of Venue Cap`)/n())

takeover <- full %>%
  mutate(Takeover = case_when(
    str_detect(Notes, regex("Takeover Tour", ignore_case = TRUE)) ~ "yes",
    TRUE ~ "no"
  )) %>%
  group_by(Takeover) %>%
  summarize(average_attendance = sum(`Published Attendance`)/n())

no_takeover <- full %>%
  mutate(Takeover = case_when(
    str_detect(Notes, regex("Takeover Tour", ignore_case = TRUE)) ~ "yes",
    TRUE ~ "no"
  )) %>%
  filter(Takeover != "yes") %>%
  mutate(month_year = floor_date(Date, "month"))

by_home_team <- no_takeover %>%
  group_by(`Home Team`) %>%
  summarize(average_attendance = sum(`Published Attendance`)/n())

ggplot(no_takeover, aes(x = Date, y = `Percent of Venue Cap`, color = `Home Team`)) +
  geom_jitter() +
  geom_smooth(method = "lm", se = FALSE) +
  theme_minimal() +
  facet_wrap(~ season, scales = "free_x") +
  labs(title = "New York and Seattle have seen the sharpest increase in game attendance over the past season",
       subtitle = "Percent of venue size filled at PWHL games, excluding the Takeover Tour",
       caption = "PWHL via Jenness Wayne") 

no_takeover$`Home Team` <- factor(
  no_takeover$`Home Team`,
  levels = c("New York", "Boston", "Minnesota", "Toronto", "Ottawa", "Montréal", "Vancouver", 
             "Seattle")
)

ggplot(no_takeover, aes(x = id, y = `Published Attendance`, 
                        fill = `Home Team`)) +
  geom_stream() +
  theme_minimal() +
  scale_y_continuous(labels = scales::comma) +
  labs(title = "Expansion teams are driving increased attendance at PWHL games",
       subtitle = "Total published attendance at PWHL games since the league's creation in 2024",
       caption = "PWHL via Jenness Wayne") 
  
